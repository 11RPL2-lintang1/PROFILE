<?php 
echo "NAMA = SATRIO LINTANG BAGASKORO";
echo "KELAS = 11 RPL 2";
echo "NO ABSEN = 35";

?>